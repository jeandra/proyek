/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
    "./app/Views/**/*.php",
    "./app/Views/**/*.html",
    "./public/**/*.html"
    ],
    theme: {
    extend: {},
    },
    plugins: [],
}
